# Awesome Codex Skills — optional candidates

Source: https://github.com/composio-community/awesome-codex-skills

The upstream Skills are **not installed or bundled**. Review each SKILL.md, license, scripts, permissions and dependencies before installing; pin a reviewed commit.

| Skill | Purpose |
| --- | --- |
| create-plan | Planning |
| codebase-migrate | Large refactoring |
| gh-fix-ci | CI diagnostics |
| gh-address-comments | PR feedback |
| webapp-testing | Web testing |
| skill-creator | Skill authoring |
| skill-installer | Skill management |

Skill directories: `https://github.com/composio-community/awesome-codex-skills/tree/master/<skill-name>`.
