# Project profile
- Name: TODO
- Goal: TODO
- Target users: TODO
- Technology: undecided
- Acceptance criteria: TODO
- Constraints: TODO
- External integrations: none until configured
