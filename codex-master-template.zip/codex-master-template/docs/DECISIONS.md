# Decisions

ADR-001: Language-agnostic baseline; no stack selected.

ADR-002: Autonomous local development, guarded irreversible actions.
