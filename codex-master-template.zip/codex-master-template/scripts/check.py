from pathlib import Path
import tomllib
root = Path(__file__).resolve().parents[1]
required = ['AGENTS.md', '.codex/config.toml', 'docs/PROJECT.md', 'workflows/new-project.md', '.github/workflows/ci.yml']
for path in required:
    assert (root / path).is_file(), f'Missing: {path}'
config = tomllib.loads((root / '.codex/config.toml').read_text())
for name, agent in config['agents'].items():
    if isinstance(agent, dict) and 'config_file' in agent:
        assert (root / '.codex' / agent['config_file']).is_file(), name
for skill in (root / '.agents/skills').glob('*/SKILL.md'):
    assert skill.read_text().startswith('---\nname: '), skill
print('Template structure OK. Project-specific build/lint/test NOT configured.')
