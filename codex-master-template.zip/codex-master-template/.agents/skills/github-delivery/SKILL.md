---
name: github-delivery
description: Prepare safe GitHub branches, commits and draft pull requests.
---
# github-delivery
Check remote and permissions; avoid direct default-branch pushes; attach test evidence; obtain approval for merges, visibility and release changes.
