---
name: quality-gate
description: Validate changes with real tests, regression checks and security inspection.
---
# quality-gate
Identify actual project checks; run them; inspect diff for secrets and regressions; retry up to 3 times; never claim unexecuted checks passed.
