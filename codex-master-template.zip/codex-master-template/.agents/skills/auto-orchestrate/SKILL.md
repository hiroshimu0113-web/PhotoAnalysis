---
name: auto-orchestrate
description: Coordinate complex coding tasks using scoped Codex subagents when available.
---
# auto-orchestrate
Read AGENTS.md; decompose work; delegate independent tasks only; integrate outputs; run checks; stop at approval boundaries.
