# Codex Master Template

汎用・高自動化型のCodex開発テンプレート。調査・設計・実装・テスト・レビューを役割分担し、必要な場合のみサブエージェントを起動します。

## 利用方法
1. GitHubにこのフォルダをpushし、Settings > General > Template repositoryを有効化。
2. Use this templateで新規リポジトリを作る。
3. Codexで開き、`docs/PROJECT.md`の目標・受入条件を記入。
4. 「AGENTS.mdとworkflows/new-project.mdに従って作業を開始して」と依頼。

## 内容
- AGENTS.md: 安全境界、役割分担、自動作業の基本ルール
- .codex/: Codexマルチエージェント設定（利用中のCodexバージョンで互換性を確認）
- .agents/skills/: テンプレート独自の再利用可能なSkills
- workflows/: 開発、修正、レビュー、リリース手順
- docs/UPSTREAM_SKILLS.md: Awesome Codex Skillsからの選定候補
- .github/: CI、Issue、PRテンプレート

外部Skillsのコードは同梱していません。候補を確認してから選択的に導入してください。CIはテンプレート構造のみ検証します。プロジェクト固有のテストは別途設定が必要です。
