import subprocess
import sys
import pathlib
import unittest

class TestTemplate(unittest.TestCase):
    def test_structure(self):
        root = pathlib.Path(__file__).resolve().parents[1]
        result = subprocess.run([sys.executable, str(root/'scripts/check.py')], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
