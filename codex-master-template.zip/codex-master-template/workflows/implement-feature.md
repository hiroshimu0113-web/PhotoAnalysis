# implement-feature

Define acceptance criteria; inspect affected files; implement minimal scoped change; test; review; record outcomes; prepare PR if authorized.
