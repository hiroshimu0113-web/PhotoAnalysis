# new-project

Read project profile; research existing code; create acceptance criteria and architecture; scaffold with tests; independently review; update progress; prepare draft PR if authorized.
