# release

Check tests, rollback and release notes; obtain explicit approval before publishing, merging or deploying; record verified outcome.
